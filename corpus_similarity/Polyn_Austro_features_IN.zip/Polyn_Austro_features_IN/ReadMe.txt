
Polynesian / Austronesian languages : their register corpor used for extracting language features (5k, char 4-gram)  



'ceb': ['Bibles_LTI', 'JW300', 'Wikipedia']

'cha': ['Bibles_LTI', 'Wikipedia']        

'fij': ['JW300',  'Wikipedia']

'haw': ['Bibles_LTI',  'Wikipedia']

'hmo': ['Bibles_LTI', 'JW300' ] 

'ilo': ['Wikipedia', 'JW300' ]

'jav': ['Wikipedia', 'JW300' ]

'mlg': ['GlobalVoices', 'Wikipedia', 'JW300' ]

'mri': ['academic', 'Bibles_LTI', 'BroadcastCorpus', 'hansard', 'legal', 'twitter', 'Wikipedia']

'msa': ['OpenSubs', 'QED', 'Tanzil', 'Wikipedia']   
        
'smo': ['Bibles_LTI', 'JW300', 'Wikipedia']

'sun': ['JW300', 'Wikipedia']        
        
'tah': ['JW300', 'Wikipedia']

'tgl': ['Bibles_LTI', 'JW300', 'OpenSubs', 'Tatoeba', 'Twitter',  'Wikipedia']

'ton': ['Bibles_LTI', 'JW300', 'Wikipedia']
      
'tvl': ['JW300']  